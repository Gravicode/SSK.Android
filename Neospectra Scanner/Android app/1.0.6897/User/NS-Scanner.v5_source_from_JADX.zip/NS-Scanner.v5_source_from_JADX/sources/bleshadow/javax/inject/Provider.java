package bleshadow.javax.inject;

public interface Provider<T> {
    T get();
}
