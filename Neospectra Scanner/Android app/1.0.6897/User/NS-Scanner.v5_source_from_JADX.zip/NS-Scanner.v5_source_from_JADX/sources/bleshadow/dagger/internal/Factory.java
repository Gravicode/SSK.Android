package bleshadow.dagger.internal;

import bleshadow.javax.inject.Provider;

public interface Factory<T> extends Provider<T> {
}
