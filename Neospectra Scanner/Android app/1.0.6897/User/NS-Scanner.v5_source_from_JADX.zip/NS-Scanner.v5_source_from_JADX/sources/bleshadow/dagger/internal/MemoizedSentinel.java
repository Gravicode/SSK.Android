package bleshadow.dagger.internal;

public final class MemoizedSentinel {
}
