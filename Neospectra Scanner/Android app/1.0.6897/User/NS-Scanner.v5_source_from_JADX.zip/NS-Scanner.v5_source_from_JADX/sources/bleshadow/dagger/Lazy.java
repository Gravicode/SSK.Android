package bleshadow.dagger;

public interface Lazy<T> {
    T get();
}
