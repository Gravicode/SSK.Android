package bleshadow.dagger.internal;

public @interface GwtIncompatible {
}
